package com.codegym.repository;

import com.codegym.model.Employees;
import com.codegym.model.Group;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface EmployeeRepository extends PagingAndSortingRepository<Employees,Long> {
    Iterable<Employees>findAllByGroup(Group group);
    Page<Employees> findAllByName(String name, Pageable pageable);
}
