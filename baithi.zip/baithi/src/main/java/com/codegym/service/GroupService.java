package com.codegym.service;

import com.codegym.model.Group;

public interface GroupService {
    Iterable<Group>findAll();
    void save(Group group);
    void remove(Long id);
    Group finById(Long id);

}
