package com.codegym.controller;

import com.codegym.model.Employees;
import com.codegym.model.Group;
import com.codegym.service.EmployeeService;
import com.codegym.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Optional;
@Controller
public class EmployeeController {

        @Autowired
        private EmployeeService employeeService;
        @Autowired
        private GroupService groupService;

        @ModelAttribute("groups")
        public Iterable<Group> groups() {
            return groupService.findAll();
        }
        @GetMapping("/employees")
        public ModelAndView listEmployees(@RequestParam("s") Optional<String> s, Pageable pageable){
            Page<Employees> employees;
            if (s.isPresent()){
                employees = employeeService.findAllByName(s.get(),pageable);
            }else {
                employees = employeeService.findAll(pageable);
            }
            ModelAndView modelAndView = new ModelAndView("/employee/list");
            modelAndView.addObject("employees", employees);
            return modelAndView;
        }
        @GetMapping("/create-employee")
        public ModelAndView showCreateEmployee(){
            ModelAndView modelAndView = new ModelAndView("/employee/create");
            modelAndView.addObject("employee",new Employees());
            return modelAndView;

        }
        @PostMapping("/create-employee")
        public ModelAndView saveEmployee(@ModelAttribute("employee") Employees employees){
            employeeService.save(employees);
            ModelAndView modelAndView = new ModelAndView("/employee/create");
            modelAndView.addObject("employees",new Employees());
            modelAndView.addObject("message","New employee created successfully");
            return modelAndView;

        }
        @GetMapping("/edit-employee/{id}")
        public ModelAndView showEditEmployee(@PathVariable Long id){
            Employees employees = employeeService.findById(id);
            if (employees != null){
                ModelAndView modelAndView = new ModelAndView("/employee/edit");
                modelAndView.addObject("employee",employees);
                return modelAndView;
            }
            ModelAndView modelAndView = new ModelAndView("/eror404");
            return modelAndView;


        }
        @PostMapping("/edit-employee")
        public ModelAndView updateEmployee(@ModelAttribute("customer")Employees employees){
            employeeService.save(employees);
            ModelAndView modelAndView = new ModelAndView("/employee/edit");
            modelAndView.addObject("employee",employees);
            modelAndView.addObject("message","employee update");
            return modelAndView;
        }
        @GetMapping("/delete-employee/{id}")
        public ModelAndView showDeleteEmployee(@PathVariable Long id){
            Employees employees = employeeService.findById(id);
            if (employees != null){
                ModelAndView modelAndView = new ModelAndView("/employee/delete");
                modelAndView.addObject("employee",employees);
                return modelAndView;
            }
            ModelAndView modelAndView = new ModelAndView("eror404");
            return modelAndView;

        }
        @PostMapping("/delete/employee")
        public String moveEmployee(@ModelAttribute("employee")Employees employees){
            employeeService.remove(employees.getId());
            return "redirect:employees";
        }



    }


