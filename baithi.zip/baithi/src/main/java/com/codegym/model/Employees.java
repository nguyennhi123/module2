package com.codegym.model;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;


@Entity
@Table(name = "employees")
public class Employees implements Validator {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotEmpty
    private String code;
    @ManyToOne
    @JoinColumn(name = "groupId")
    private Group group;
    @NotEmpty
    private String name;
    @NotEmpty
    private String sex;
    private String phoneNumber;
    @NotEmpty
    @Email
    private String email;

    public Employees() {
    }

    public Employees(@NotEmpty String code, Group group, @NotEmpty String name, @NotEmpty String sex, String phoneNumber, @NotEmpty @Email String email) {
        this.code = code;
        this.group = group;
        this.name = name;
        this.sex = sex;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public boolean supports(Class<?>clazz){
        return Employees.class.isAssignableFrom(clazz);

    }
    @Override
    public void validate(Object target, Errors error){
        Employees employees = (Employees) target;
        String phoneNumber = employees.getPhoneNumber();
        ValidationUtils.rejectIfEmpty(error,"phoneNumber","phoneNumber.empty");
        if (phoneNumber.length()>11 || phoneNumber.length()<10){
            error.rejectValue("phoneNumber", "phoneNumber.length");
        }
        if (!phoneNumber.startsWith("0")){
            error.rejectValue("phoneNumber", "phoneNumber.startsWith");
        }
        if (!phoneNumber.matches("(^$|[0-9]*$)")){
            error.rejectValue("phoneNumber", "phoneNumber.matches");
        }

    }
}
